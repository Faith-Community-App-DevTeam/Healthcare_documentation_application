CLIENT_BUCKET = f"fcn-clients"
USER_BUCKET = f"fcn-users"
REGION_NAME = "us-east-1"

